class Firstclass{
    public static void main(String args[]){
        System.out.println("Name: "+ args[0]+'\n'+"Surname: "+args[1]+'\n'+"Age: "+args[2]+'\n'+"occupation: "+args[3]);
    }
}